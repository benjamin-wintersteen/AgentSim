Run the Program using java AgentSimulation
This program Introduces Viruses to our Landscape
1st arg: Updates number of Agents [int: 0-1000]
2nd arg: Updates width [int: 0-10000]
3rd arg: Updates height [int: 0-10000]
4th arg: Updates the radius [int: 0-10000]